<?php
//Discuz! cache file, DO NOT modify me!
//Identify: aa48ccc5c966b8bf7f040ed05827bc61

$pluginsetting = array (
);
?>