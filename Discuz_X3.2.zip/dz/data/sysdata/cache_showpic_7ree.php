<?php
//Discuz! cache file, DO NOT modify me!
//Identify: fb5d9dc1774c13613c6c4c2339153d19

$pic_7ree=array (
  0 => 
  array (
    'picpics' => 'data/attachment/forum/201612/05/144354xvgptnz6kzt6ntim.jpg',
    'attachment' => '201612/05/144354xvgptnz6kzt6ntim.jpg',
    'piclinks' => 'forum.php?mod=viewthread%26tid=5',
    'pictexts' => 'Only For Test',
    'attaid' => NULL,
  ),
  1 => 
  array (
    'picpics' => 'data/attachment/forum/201611/10/162946wi3hzhs2x2alhcra.jpg',
    'attachment' => '201611/10/162946wi3hzhs2x2alhcra.jpg',
    'piclinks' => 'forum.php?mod=viewthread%26tid=4',
    'pictexts' => 'Only For Test',
    'attaid' => NULL,
  ),
  2 => 
  array (
    'picpics' => 'data/attachment/forum/201611/10/162824rarlrk26nobneks6.jpg',
    'attachment' => '201611/10/162824rarlrk26nobneks6.jpg',
    'piclinks' => 'forum.php?mod=viewthread%26tid=3',
    'pictexts' => 'Only For Test',
    'attaid' => NULL,
  ),
);
?>