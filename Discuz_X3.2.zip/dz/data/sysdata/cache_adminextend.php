<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 987295f91f4849997d3f2466b19e8838

$adminextend = array (
  0 => 'cloud.php',
);
?>