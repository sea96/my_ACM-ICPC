<?PHP exit;?>	1480925559	BaoHai	1	127.0.0.1	login		38	GET={mod=modcp; fid=38; action=login; }; POST={};
<?PHP exit;?>	1480943838	BaoHai	1	127.0.0.1	login		61	GET={mod=modcp; fid=61; action=login; }; POST={};
