<?PHP exit;?>	1478615617	BaoHai	1	::1	login		37	GET={mod=modcp; fid=37; action=login; }; POST={};
<?PHP exit;?>	1478615623	BaoHai	1	::1	thread		37	GET={mod=modcp; fid=37; action=thread; }; POST={};
<?PHP exit;?>	1478615637	BaoHai	1	::1	forumaccess		37	GET={mod=modcp; action=forumaccess; fid=37; }; POST={};
<?PHP exit;?>	1478615643	BaoHai	1	::1	home		37	GET={mod=modcp; action=home; fid=37; }; POST={};
