<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?><?php
$__FORMHASH = FORMHASH;$robot_html = <<<EOF

<div>

    <link rel="stylesheet" type="text/css" href="source/plugin/htt_robot/template/style.css" />

    <script src="source/plugin/htt_robot/template/jquery.js" type="text/javascript"></script>

    <div id="robot_container_closed">
        <div id="robot_container_closed_body" style="width: 60px;height: 60px;">
            
        </div>
        <!--���ǻ�����-->
    </div>


    <div id="robot_container_open">
        <div class="title" id="robot_title">
            <img src="source/plugin/htt_robot/template/image/robot.png" alt="">
            <span>{$robot_name}</span>
            <div class="headBtn"><a hidefocus="" href="javascript: void(0);" class="zhichiVoice" title="开/光 声音"></a> <a hidefocus="" href="javascript: void(0);" class="zhichiMin" title="最小化"></a> <a hidefocus="" href="javascript: void(0);" class="zhichiMax" title="最大化"></a> <a hidefocus="" href="javascript: void(0);" class="zhichiClose" title="关闭会话"></a></div>
        </div>
        <div class="fengexian"></div>

        <ul class="wechat">
            <li class="robot">
                <span>{$robot_name}</span>
                <div>
                    {$welcome_msg}
                </div>
            </li>



        </ul>

        <div class="do_area">

                <!--<input type="text" name="msg" id="" value="����˵2��">-->

            <textarea cols="50" rows="5" id="inputMsg" class="text grey">请输入...</textarea>
                <!--<button type="button" id="send_button">����</button>-->
            <p id="help">
                提示:点我,则随机返回别人的问题。立即试试吧。例如 笑话
            </p>

        </div>
        <div class="powBox"><p class="pow">Powered by 北岸的云</p>
            <button type="button" class="btn pull-btn" id="pullBtn" style="color: rgb(255, 255, 255); background: rgb(19, 201, 203);">点我</button>
            <button type="button" class="btn send-btn" id="sendBtn" style="color: rgb(255, 255, 255); background: rgb(19, 201, 203);">发送</button>
        </div>


    </div>

    <!--js��Ҫ�����԰�-->
    <input type="hidden" id="close_text" value="要离开我吗?呜呜呜。。。">
    <input type="hidden" id="error_empty" value="内容不可以为空哟">
    <input type="hidden" id="me" value="我">
    <input type="hidden" id="robot_bug" value="哎呀,脑袋坏掉了，请联系我的主人">
    <input type="hidden" id="please_input" value="请输入...">
    <input type="hidden" id="discuzurl" value="{$site_url}">
    <input type="hidden" id="formhash" value="{$__FORMHASH}">
    <!--<script src="source/plugin/htt_robot/template/drag.js" type="text/javascript" type="text/javascript"></script>-->
    <script src="source/plugin/htt_robot/template/draggabilly.pkgd.js" type="text/javascript" type="text/javascript"></script>
<script type="text/javascript">

    var moli_datas_str = "财神爷灵签;月老灵签;观音灵签;签语;注释;解签;白话";

    var moli_datas = moli_datas_str.split(';');

//    console.log(moli_datas[0]);


    var jq = jQuery.noConflict();
    function setCookie(name,value)
    {
        var Days = 30;
        var exp = new Date();
        exp.setTime(exp.getTime() + Days*24*60*60*1000);
        document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
    }


    function getCookie(name)
    {
        var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        if(arr=document.cookie.match(reg))
            return unescape(arr[2]);
        else
            return null;
    }


    var Draggabilly = window.Draggabilly;
    var draggie = new Draggabilly( '#robot_container_closed' );
    function listener(/* parameters */) {
        // get Draggabilly instance
        var draggie = jq(this).data('draggabilly');
        console.log( 'eventName happened', draggie.position.x, draggie.position.y );
    }
// bind event listener
    draggie.on( 'staticClick', function( event, pointer ) {
        if(event.type=='mouseup'){
            jq('#robot_container_closed').hide();
           jq('#robot_container_open').show();
            setCookie('robot_status',1)
        }
    });

    draggie.on( 'dragEnd', function( event, pointer ) {
        //�洢����һ��ʹ�á�
        setCookie('robot_pointer_x',pointer.pageX);
        setCookie('robot_pointer_y',pointer.pageY);
    });



</script>


    <script src="source/plugin/htt_robot/template/robot.js?t={$t}" type="text/javascript"></script>








</div>

EOF;
?>