<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div id="user">
<?php if($_G['uid']) { ?>
<ul>
<li>
<a href="javascript:;" id="myq" class="mry" onmouseover="showMenu(this.id);" initialized="true">快捷导航</a>
</li>
<li>
<a href="home.php?mod=spacecp&amp;ac=profile">设置</a>
</li>
<li>
<a href="home.php?mod=space&amp;do=notice" id="myprompt" class="mry" onmouseover="showMenu({'ctrlid':'myprompt'});">
提醒
<?php if($_G['member']['newprompt']) { ?>
<span style="background: #169EF8;border-radius: 50%;padding: 0 2px;">+!</span>
<?php } ?>
</a>
<span id="myprompt_check"></span>
<?php if(empty($_G['cookie']['ignore_notice']) && ($_G['member']['newpm'] || $_G['member']['newprompt_num']['follower'] || $_G['member']['newprompt_num']['follow'] || $_G['member']['newprompt'])) { ?><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><?php } if($_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])) { ?>
<a href="home.php?mod=task&amp;item=doing" id="task_ntc" class="mry">进行中的任务</a>
<?php } ?>
</li>
<?php if($_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])) { ?>
<li>
<a href="home.php?mod=task&amp;item=doing" id="task_ntc" class="new">进行中的任务</a>
</li>
<?php } ?>
<!--切换宽窄-->
<?php if(empty($_G['disabledwidthauto']) && $_G['setting']['switchwidthauto']) { ?>
<li>
<a href="javascript:;" id="switchwidth" onclick="widthauto(this)" title="<?php if(widthauto()) { ?>切换到窄版<?php } else { ?>切换到宽版<?php } ?>" class="switchwidth swit">
<?php if(widthauto()) { ?>切换到窄版<?php } else { ?>切换到宽版<?php } ?>
</a>
</li>
<?php } ?>
<li class="m-t nav-c"><?php echo avatar($_G[uid],middle);?></li>
</ul>
<div class="user-box">
<div class="box-b cl">
<div class="m-t z">
<a href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>" class="fc1" id="myimg_top" onmouseover="showMenu({'ctrlid':'myimg_top','pos':'34!','ctrlclass':'a','duration':2});" initialized="true"><?php echo avatar($_G[uid],middle);?></a>
</div>
<div class="y">
<p>用户名:<a href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>" class="mry" target="_blank" title="访问我的空间"><?php echo $_G['member']['username'];?></a></p>
<?php if(($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))) { ?>
<p>
<a href="portal.php?mod=portalcp"><?php if($_G['setting']['portalstatus'] ) { ?>门户管理<?php } else { ?>模块管理<?php } ?></a>
</p>
<?php } if($_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)) { ?>
<p>
<a href="admin.php" target="_blank">管理中心</a>
</p>
<?php } if($_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']) { ?>
<p>
<a href="admin.php?frames=yes&amp;action=cloud&amp;operation=applist" target="_blank">云平台</a>
</p>
<?php } if($_G['uid'] && $_G['group']['radminid'] > 1) { ?>
<p>
<a href="forum.php?mod=modcp&amp;fid=<?php echo $_G['fid'];?>" target="_blank"><?php echo $_G['setting']['navs']['2']['navname'];?>管理</a>
</p>
<?php } ?>
<p>
<a href="home.php?mod=spacecp&amp;ac=avatar">上传头像</a>
</p>
<p>
<a href="home.php?mod=spacecp&amp;ac=profile&amp;op=password">修改密码</a>
</p>
<?php if(check_diy_perm($topic)) { ?>
<p>
<a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" class="mry">DIY设置</a>
</p>
<?php } ?>
</div>
</div>
<p>
<?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra1'])) echo $_G['setting']['pluginhooks']['global_usernav_extra1'];?>
<?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra2'])) echo $_G['setting']['pluginhooks']['global_usernav_extra2'];?>
<?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra3'])) echo $_G['setting']['pluginhooks']['global_usernav_extra3'];?>
</p>
<div class="box-f cl">
<a href="home.php?mod=space" class="z"><i class="fa fa-2x fa-user" aria-hidden="true"></i>&nbsp;我的空间</a>
<a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>" class="y" title="退出登录"><i class="fa fa-2x fa-power-off" aria-hidden="true"></i>&nbsp;注销</a>
</div>
</div>
<?php } elseif(!empty($_G['cookie']['loginuser'])) { ?>
<ul>
<li><a id="loginuser" class="noborder"><?php echo dhtmlspecialchars($_G['cookie']['loginuser']); ?></a></li>
<li><a href="member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href)">激活</a></li>
<li><a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">退出</a></li>
</ul>
<?php } elseif(!$_G['connectguest']) { ?>
<ul>
<li>
<a href="member.php?mod=logging&amp;action=login" class="login_bn" onclick="showWindow('login', this.href);return false;" rel="nofollow"><strong>登录</strong></a>
</li>
<li>
<!--合作站点账号登陆-->
<a href="connect.php?mod=login&amp;op=init&amp;referer=index.php&amp;statfrom=login_simple">QQ登陆</a>
</li>
<li>
<a href="member.php?mod=<?php echo $_G['setting']['regname'];?>" class="xi2 xw1"><?php echo $_G['setting']['reglinkname'];?></a>
</li>
</ul>
<?php } else { ?>
<ul class="my_userbox">
     <li><a class="mry"><strong class="vwmy qq"><?php echo $_G['member']['username'];?></strong></a></li>
     <li><a class="mry" href="member.php?mod=connect" target="_blank" title="体验本站更多功能">完善帐号信息</a></li>
     <li><a class="mry" href="member.php?mod=connect&amp;ac=bind" target="_blank" title="使用QQ帐号快速登录本站">绑定已有帐号</a><li>
     <li><a class="mry" href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">退出</a></li>
</ul>
<?php } ?>
</div>