<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'bh_discuz');
define('UC_DBPW', 'ya3NL9FfA9H47Ban');
define('UC_DBNAME', 'bbs_discuz');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`bbs_discuz`.zstubbs_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'Ber313acw6C5M1k2xdKcScme2eR4Z3j4H9wdu74aubd1JaO0nfgcA6Z9sd50q0i6');
define('UC_API', 'http://localhost/dz/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>